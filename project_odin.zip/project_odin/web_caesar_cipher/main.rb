require 'sinatra'
require 'sinatra/reloader'

def caesar_cipher(text_to_decript, n)
	return_value = ""
	split_text = text_to_decript.split("")

	split_text.each do |letter|
		ord_letter = letter.ord	
		if ord_letter>=96 and ord_letter<=122
			ord_letter+= n
			if ord_letter >122
				ord_letter = 96 + ord_letter - 122
			end
		elsif ord_letter>=65 and ord_letter<=90
			ord_letter+= n
			if ord_letter>90
				ord_letter = 64 + ord_letter - 90
			end
		end
		return_value += ord_letter.chr
	end
	return_value
end


get "/" do
	decrypted_message = caesar_cipher(params["text"], params["amount_to_move"].to_i)
	puts params
	erb :index, :locals => {:message => decrypted_message}
end