class Post < ApplicationRecord
	validates :title, :url,  length: {within: 5..50} 
	belongs_to :user
end
