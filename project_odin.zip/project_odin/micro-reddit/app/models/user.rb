class User < ApplicationRecord
	validates :name, length: {within: 5..20}, uniqueness: true, presence: true
	validates :email, length: {within: 5..40}, presence: true, format: {with: /\A([\w+\-].?)+@[a-z\d\-]+(\.[a-z]+)*\.[a-z]+\z/i}

	has_many :posts
end
