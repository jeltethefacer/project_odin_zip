require 'sinatra'
require 'sinatra/reloader'

require "./functions.rb"

possible_colors = ["blue", "red", "green", "yellow", "purple", "orange"]
code = []
previous_guesses = []

for x in 0...4
	code << possible_colors[Helper.random_number(6)]
end

get "/" do
	guess = [params["color0"], params["color1"], params["color2"], params["color3"]]
	guess_copy = guess.dup
	if(guess[0])
		red_pegs = Helper.get_red_pegs(guess_copy.dup, code.dup)
		white_pegs = Helper.get_white_pegs(guess_copy.dup, code.dup)
		guess << white_pegs
		guess << red_pegs
		previous_guesses << guess
	end
	erb :index, :locals => {:message => code, :possible_colors => possible_colors, :previous_guesses => previous_guesses}
end