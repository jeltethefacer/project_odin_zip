module Helper
	def Helper.random_number(max)
		random = Random.new()
		return random.rand(max)
	end

	def Helper.get_red_pegs(code_to_check, code)
		red_pegs = 0
		3.downto(0	).each do |x|
			if code_to_check[x] == code[x]
				red_pegs+=1
			end
		end
		return red_pegs
	end

	def Helper.get_white_pegs(code_to_check, code)
		white_pegs = 0
		3.downto(0).each do |x|
			if code_to_check[x] == code[x]
					code_to_check.delete_at(x)
					code.delete_at(x)
			end
		end
		for x in 0..code_to_check.length
			a = code.find_index(code_to_check[x])
			if a
				white_pegs +=1 
				code.delete_at(a)
			end
		end

		white_pegs
	end
end