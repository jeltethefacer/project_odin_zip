class User < ApplicationRecord
	validates :username, :email, :password, precense: true
end
