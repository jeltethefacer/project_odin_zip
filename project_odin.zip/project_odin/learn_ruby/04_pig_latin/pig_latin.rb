#write your code here
def translate(scentence)
	words = scentence.split(" ")
	return_value = ""
	words.each do |word|
		while true do 
			if word[0] == "a" || word[0] == "e" || word[0] == "i" || word[0] == "o" || word[0] == "u"
				return_value += word + "ay "
				break
			else
				contensant = word[0]
				
				word[0] = ""
				word += contensant 
			end
		end
	end
	return return_value.chomp(" ")
end