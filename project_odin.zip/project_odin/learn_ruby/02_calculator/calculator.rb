#write your code here
def add(a, b)
	return a + b
end

def subtract(a,b)
	return a -b
end

def sum(array)
	return_value = 0
	array.each do |number|
		return_value += number
	end
	return return_value
end

def multiply(a, b)
	return a*b
end

def power(a, b)
	return a ** b
end

def factorial