#write your code here
def ftoc(f)
	return (f-32)*5/9
end

def ctof(c)
	return (c* 9/5 + 32).to_f
end
