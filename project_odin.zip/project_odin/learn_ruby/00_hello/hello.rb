#write your code here
def hello 
	return "Hello!"
end	
    def greet(who)
      "Hello, #{who}!"
    end