class Timer
	def initialize
	 	@seconds = 0
	end

	def seconds
		return @seconds
	end

	def seconds=(seconds)
		@seconds = seconds
	end
	  
	def time_string
		return_value = ""
		hours = (@seconds / 3600).floor
  		minutes = ((@seconds / 60).floor )% 60
  		seconds = @seconds % 60
  		if hours < 10
  			return_value += "0" + hours.to_s + ":"
  		else 
  			return_value +=  hours.to_s + ":"
  		end
  		if minutes < 10
  			return_value += "0" + minutes.to_s + ":"
  		else 
  			return_value +=  minutes.to_s + ":"
  		end
  		 if seconds < 10
  			return_value += "0" + seconds.to_s 
  		else 
  			return_value +=  seconds.to_s 
  		end
  		return return_value

  	end
end


