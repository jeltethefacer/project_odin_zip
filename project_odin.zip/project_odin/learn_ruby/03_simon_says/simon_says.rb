#write your code here
def echo(echo)
	return echo
end

def shout(word)
	return word.upcase
end

def repeat(word, times=2)
	return_value = ""
	times.times do 
		return_value += word+ " "
	end
	return_value = return_value.chomp(" ")
	return return_value
end

def start_of_word(word, number_of_letters)
	return word[0...number_of_letters]
	end
def first_word (word)
	end_of_word_index = word.index(" ")
	return word[0...end_of_word_index]
end

def titleize(word)
	split_word = word.split(" ")
	return_value = ""
	split_word.each_with_index do |single_word, index|
		if (single_word =="and" || single_word=="or" || single_word=="the" || single_word=="over") && index != 0
			return_value += single_word + " "
		else
			return_value += single_word.capitalize + " "
		end

	end
	return_value = return_value.chomp(" ")
	return return_value	
end
