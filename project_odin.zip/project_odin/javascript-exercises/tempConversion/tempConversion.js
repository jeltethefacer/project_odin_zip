var ftoc = function() {
  
}

var ctof = function() {
  
}

module.exports = {
  ftoc,
  ctof
}
