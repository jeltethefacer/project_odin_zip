# Exercise 06 - tempConversion

This exercise asks you to create more than one function so the module.exports section of the spec file looks a little different this time.  Nothing to worry about, we're just packaging the functions into an object to be exported.

Write two functions that convert temperatures from Fahrenheit to Celsius (and the other way around):
```
ftoc(32) // fahrenheit to celsius, should return 0

ctof(0) // celsius to fahrenheit, should return 32
```


## hints
The math here is fairly straightforward.. just google the formula and implement it in the code
