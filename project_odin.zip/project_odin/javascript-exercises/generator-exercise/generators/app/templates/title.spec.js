var <%= title %> = require('./<%=title%>')

describe('<%=title%>', function() {
  it('EDITME', function() {
    expect(<%=title%>()).toEqual(' ');
  });

});
