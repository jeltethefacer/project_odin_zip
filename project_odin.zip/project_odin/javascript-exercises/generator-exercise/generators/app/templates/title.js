var <%= title %> = function() {

}

module.exports = <%= title %>
