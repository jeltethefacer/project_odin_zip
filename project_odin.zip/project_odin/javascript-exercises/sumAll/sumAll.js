var sumAll = function() {

}

module.exports = sumAll
