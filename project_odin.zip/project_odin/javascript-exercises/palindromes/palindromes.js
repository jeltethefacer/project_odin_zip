var palindromes = function() {

}

module.exports = palindromes
