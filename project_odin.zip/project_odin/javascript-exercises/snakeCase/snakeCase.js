var snakeCase = function() {

}

module.exports = snakeCase
