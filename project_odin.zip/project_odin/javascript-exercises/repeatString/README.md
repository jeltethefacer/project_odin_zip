# Exercise 02 - repeatString

Write a function that simply repeats the string a given number of times:

```javascript
repeatString('hey', 3) // returns 'heyheyhey'
```

You will notice in this exercise that there are multiple tests, after making the first one pass, enable the others one by one by deleting the x in front of the it() function.


## hints

You're going to want to use a loop for this one.

Create a variable to hold the string you're going to return, create a loop that repeats the given number of times and add the given string to the result on each loop.

