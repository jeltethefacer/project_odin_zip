var repeatString = function(string, times) {
	let returnValue = ""
	for(let x = 0; x<times;x++){
		returnValue += string;
	}
	return returnValue;
}
console.log(repeatString("hey", 0));


module.exports = repeatString
