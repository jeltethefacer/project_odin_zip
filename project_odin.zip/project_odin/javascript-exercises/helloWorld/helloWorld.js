var helloWorld = function() {
  return 'Hello, World!'
}

module.exports = helloWorld