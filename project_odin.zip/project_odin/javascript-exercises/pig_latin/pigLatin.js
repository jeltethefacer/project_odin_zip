function translate() {
	// body...
}


module.exports = {
	translate
}

