var removeFromArray = function() {

}

module.exports = removeFromArray
