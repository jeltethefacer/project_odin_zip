var fibonacci = function() {

}

module.exports = fibonacci
