class Hangman
	def initialize(file)
		@word = self.get_word(file)
		@guessed_letters = []
		@wrong_guesses = 0
		@tries = 10
		@word_to_show = []
		@word.length.times do 
			@word_to_show << "_"
		end
	end

	def get_word(file)
		words = []
		File.open(file, "r").readlines.each do |word|
			word = word.chop
			if(word.length.between?(5,12) && /[[:lower:]]/.match(word[0]))
					words << word
			end
		end
		return words[rand(0..words.length)]
	end

	def show_word
		puts "\n"
		puts "#{@word}"
		puts "the letter your already guessed are: #{@guessed_letters.join(" ")}"
		puts "you've used #{@wrong_guesses} out of the #{@tries}"
		puts "this is the word with your guessed letters #{@word_to_show.join(" ")}"
	end

	def guess_letter
		puts "enter a single letter you want to guess"
		letter = gets.chop[0].downcase
		if(letter =~ /[a-z]/)
			letter_in_word = false
			@word.length.times do |index|
				if(@word[index] == letter)
					@word_to_show[index] = letter
					letter_in_word = true
				end
			end
			unless(letter_in_word)
				@wrong_guesses += 1
			end
		else
			puts "Your input is not right enter something else."
		end
	end
end