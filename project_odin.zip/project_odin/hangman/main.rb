require "./Hangman.rb"

game = Hangman.new("5desk.txt")



while true
	game.show_word
	puts "what do you want to do"
	puts "[1] enter a letter"
	puts "[2] guess the word"
	puts "[3] save the game"
	choice = gets.chop
	case choice
	when "1"
		game.guess_letter
	when "2"
		game.guess_word
	when "3"
		game.save
	else
		puts "invalid choice reenter"
	end
end