def caesar_cipher(string, numbers_to_shift)
	new_string = string.chars
	new_string.map do |i|
		puts i
		ascii_code = i.ord
		if ascii_code>=65 && ascii_code<=90
			ascii_code += numbers_to_shift
			if ascii_code >90
				ascii_code -= 26
			end
		elsif ascii_code>=97 && ascii_code<=122
			ascii_code += numbers_to_shift
			if ascii_code >122
				ascii_code -= 26
			end
		end
		return ascii_code.chr
	end
	return string.join()
end

puts caesar_cipher("What a string!", 5)