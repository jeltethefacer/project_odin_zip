def bubble_sort(arr)
	(arr.length-1).downto(0) do |y|
		for x in 0...y
			if(arr[x]>arr[x+1])
				temp = arr[x]
				arr[x] = arr[x+1]
				arr[x+1] = temp
			end
		end
	end
	return arr	
end

def bubble_sort_by(arr)
	(arr.length-1).downto(0) do |y|
		for x in 0...y
			if(yield(arr[x],arr[x+1]) > 0) 
				temp = arr[x]
				arr[x] = arr[x+1]
				arr[x+1] = temp
			end
		end
	end
	return arr	
end




print bubble_sort([4,3,78,2,0,2,5,6,2,5,6,10921,19209,5,2,0,85,36,86,37])
print bubble_sort_by(["hi","hello","hey"]) { |left,right| left.length - right.length }