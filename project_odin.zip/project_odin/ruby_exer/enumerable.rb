  module Enumerable
    def my_each
      for x in self do 
      	yield(x)
      end
    end

    def my_each_with_index  
    	for x in 0...self.length
    		yield(self[x], x)
    	end
    end

    def my_select
    	return_array = []
    	for x in self
    		if(yield(x))
    			return_array << x
    		end
    	end
    	return return_array
    end

    def my_all?
    	for x in self
    		if(!yield(x))
    			return false
    		end
    	end
    	return true
    end

    def my_any?
    	for x in self
    		if(yield(x))
    			return true
    		end
    	end
    	return false
    end

    def my_none?
    	for x in self
    		if(yield(x))
    			return false
    		end
    	end
    	return true
    end

    def my_count
    	unless block_given?  
    		return self.length
    	end
    	return_value = 0
    	for x in self
    		if(yield(x))
    			return_value += 1
    		end
    	end
    	return return_value
    end

    def my_map 
    	return_array = []
    	for x in self
    		return_array << yield(x)
    	end
    	return return_array
    end

    def my_inject 
    	return_value = 0
    	for x in self
    		return_value += yield(x)
    	end
    	return return_value
    end
  end