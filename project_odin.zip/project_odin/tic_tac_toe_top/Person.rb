class Person 
	attr_reader :name, :icon
	def initialize(name, icon)
		@name = name
		@icon = icon
	end

	def get_move
		while true
			puts "what is the field you want to play (1 t/m 9)"
			input = gets.chop.to_i
			unless input<1 || input > 9
				return input
			end
			puts "Wrong move enter a number between 0 and 10"
		end
	end	
end