require "./Person.rb"
require "./Board.rb"

def welcome
	puts "Welcome to the awesome game of tic tac toe"
	puts "Were gonna have a lot of fun"
end

def get_name(player)
	puts "enter the name of #{player}"
	return gets.chop
end

welcome
player1 = Person.new(get_name("player 1"), "x")
player2 = Person.new(get_name("player 2"), "o")
current_player = player1
board = Board.new
board.show

while true
	puts "It's #{current_player.name}'s turn"
	move = current_player.get_move
	if(board.place_move(move, current_player.icon))
		board.show
		if(board.is_winner?)
			puts "\n#{current_player.name} WINS!!!!!!!!!!! congrats"
			break
		end
		current_player = current_player == player1 ? player2 : player1
	end
end