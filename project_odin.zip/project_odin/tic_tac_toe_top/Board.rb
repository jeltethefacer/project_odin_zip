class Board
	def initialize 
		@board = []
		3.times do 
			temp = []
			3.times do
				temp << " "
			end
			@board << temp
		end
	end

	def show
		puts ("+-+-+-+")
		for x in 0..2 
			print "|"
			for y in 0..2 
				print @board[x][y]
				print "|"
			end
			print "\n+-+-+-+ \n"
		end
	end

	def place_move(field, icon)
		#the input starts with 1 and arrays start with 0 
		field = field - 1
		x = field%3
		y = (field/3).floor
		if(@board[y][x] == " ")
			@board[y][x] = icon
			return true
		else
			return false
		end
	end

	def is_winner?()
		for x in 0..2
			icon_to_match = @board[x][0]
			number = 0
			if(icon_to_match == " ")
				break
			end
			for y in 0..2

				if(@board[x][y] == icon_to_match && @board[x][y] != " ")
					number += 1
				end
			end
			if(number == 3)
				return true
			end
		end	
		for y in 0..2
			icon_to_match = @board[0][y]
			number = 0
			if(icon_to_match == " ")
				break
			end
			for x in 0..2

				if(@board[x][y] == icon_to_match && @board[x][y] != " ")
					number += 1
				end
			end
			if(number == 3)
				return true
			end
		end	
		#the hardcoded diagonals
		if(@board[0][0] == @board[1][1] && @board[1][1] == @board[2][2] && @board[1][1]!=" ")
			return true
		end
		if(@board[2][0] == @board[1][1] && @board[1][1] == @board[0][2] && @board[1][1]!=" ")
			return true
		end


		return false
	end
end