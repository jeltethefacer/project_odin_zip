require_relative "../../../app/ledger"
require_relative "../../../config/sequel"
require_relative "../../support/db"

module ExpenseTracker
	RSpec.describe Ledger do
		let(:ledger) {Ledger.new}
		let(:expense)  do
			{
				"payee" => "starbucks",
				"amount" => 5.75,
				"date" => "2017-06-10"
			}
		end

		describe "#record" do

			context "with a valid expense" doex
				it "succesfully saves the expense to the db" do
					result = ledger.record(expense)

					expect(result).to be_succes
					expect(DB[:expenses].all).to match [a_hash_include(
						id: result.expense_id
						payee: "starbucks",
						amount: 5.75,
						date: Date.iso8601("2017-06-10")
					)]
			end
		end
	end
end