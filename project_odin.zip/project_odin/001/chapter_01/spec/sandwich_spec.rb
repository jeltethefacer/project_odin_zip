Sandwich = Struct.new(:taste, :toppings)

describe 'an ideal sandwich' do
	
	let(:sandwich){Sandwich.new('delicous', [])}

	it 'is delicous' do
		taste = sandwich.taste
		expect(taste).to eq('delicous')
	end

	it 'let me add toppings' do

		sandwich.toppings << 'cheese'
		toppings = sandwich.toppings

		expect(toppings).not_to be_empty
	end
end