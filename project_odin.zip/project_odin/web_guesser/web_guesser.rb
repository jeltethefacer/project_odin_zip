require 'sinatra'
require 'sinatra/reloader'


SECRET_NUMBER = rand(100)

def check_guess(guess)
	if guess > SECRET_NUMBER
		if guess > SECRET_NUMBER+5
			return "Way too high!"
		else
			return "Too high!"
		end
	elsif guess < SECRET_NUMBER 
		if guess < SECRET_NUMBER-5
			return "Way too low!"
		else
			return "Too low!"
		end
	elsif guess == SECRET_NUMBER 
		return "You're right!!!!"
	end
end

get '/' do
	message = ""
	player_guess = params["guess"].to_i
	message = check_guess(player_guess)
	erb :index, :locals => {:number => SECRET_NUMBER, :message => message}
end