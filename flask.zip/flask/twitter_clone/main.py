from flask import Flask, render_template, request
app = Flask(__name__)

@app.route('/')
def hello_world():
    return 'Hello, World!'

@app.route("/login")
def login():
	if request.method == 'GET':
		return render_template("login.html")
	elif request.method == "POST":
		print ("post this shit")
		return "posted"