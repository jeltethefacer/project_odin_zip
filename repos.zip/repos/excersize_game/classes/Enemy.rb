class Enemy
	def initialize()
		puts "Enemy initialized."
	end
end